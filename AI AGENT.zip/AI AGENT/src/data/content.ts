export interface Phase {
  id: string
  title: string
  subtitle?: string
  description?: string
  position: 'left' | 'right' | 'top' | 'bottom'
  alignment?: 'start' | 'center' | 'end'
}

export interface ContentData {
  title: string
  subtitle: string
  description: string
  sequence: {
    totalFrames: number
    imageFolderPath: string
    scrollLength: number
  }
  phases: Phase[]
  features: {
    title: string
    description: string
    icon?: string
  }[]
  footer: {
    title: string
    description: string
    copyright: string
  }
}

export const content: ContentData = {
  title: 'DAWN',
  subtitle: 'A Journey Through Light',
  description:
    'Experience the transformation of a city waking from darkness into the brilliance of a new day. Scroll to begin.',

  sequence: {
    totalFrames: 120,
    imageFolderPath: '/images/sequence',
    scrollLength: 500,
  },

  phases: [
    {
      id: 'intro',
      title: 'DAWN',
      subtitle: 'A Journey Through Light',
      description:
        'Experience the transformation of a city waking from darkness into the brilliance of a new day.',
      position: 'left',
    },
    {
      id: 'phase-1',
      title: 'First Light',
      subtitle: '02:47 AM',
      description:
        'The horizon begins to shift. Deep indigo surrenders to the first hints of violet and blue.',
      position: 'right',
    },
    {
      id: 'phase-2',
      title: 'Awakening',
      subtitle: '04:15 AM',
      description:
        'Shadows retreat as the city stirs. Streetlights fade, replaced by the gentle glow of approaching dawn.',
      position: 'left',
    },
    {
      id: 'phase-3',
      title: 'The Horizon',
      subtitle: '05:30 AM',
      description:
        'Golden threads weave through the sky. The promise of a new day crystallizes on the horizon.',
      position: 'right',
    },
    {
      id: 'phase-4',
      title: 'Ignition',
      subtitle: '06:15 AM',
      description:
        'Sunlight breaches the skyline. The world transforms in an instant — colors ignite, shapes emerge.',
      position: 'left',
    },
    {
      id: 'phase-5',
      title: 'Brilliance',
      subtitle: '07:00 AM',
      description:
        'Full daybreak. The city basks in the full spectrum of morning light — vibrant, alive, infinite.',
      position: 'right',
    },
    {
      id: 'final',
      title: 'BEGIN',
      subtitle: 'Experience the Light',
      description:
        'Every moment holds the potential for transformation. What will you create today?',
      position: 'bottom',
    },
  ],

  features: [
    {
      title: 'Cinematic Precision',
      description:
        '120-frame sequence rendered at 60fps with smooth interpolation and cinematic timing.',
    },
    {
      title: 'Adaptive Storytelling',
      description:
        'Content dynamically adapts to scroll position, creating an immersive narrative flow.',
    },
    {
      title: 'Performance First',
      description:
        'Optimized canvas rendering with intelligent preloading and frame caching.',
    },
    {
      title: 'Accessible Design',
      description:
        'Keyboard navigation, reduced motion support, and screen reader compatibility.',
    },
  ],

  footer: {
    title: 'Create Your Vision',
    description: 'Built with Next.js, Framer Motion, and Tailwind CSS.',
    copyright: '© 2024. All rights reserved.',
  },
}
