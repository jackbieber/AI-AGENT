'use client'

import { useRef } from 'react'
import { motion, useScroll } from 'framer-motion'
import Navbar from '@/components/Navbar'
import ScrollCanvas from '@/components/ScrollCanvas'
import ExperienceOverlay from '@/components/ExperienceOverlay'
import { content } from '@/data/content'

export default function Home() {
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  const { scrollYProgress } = useScroll({
    target: scrollContainerRef,
    offset: ['start start', 'end end'],
  })

  return (
    <main>
      <Navbar
        logoText={content.title}
        ctaText={content.phases[content.phases.length - 1]?.subtitle || 'Get Started'}
      />

      <section ref={scrollContainerRef} className="scroll-container">
        <div className="sticky-viewport">
          <ScrollCanvas
            scrollYProgress={scrollYProgress}
            totalFrames={content.sequence.totalFrames}
            imageFolderPath={content.sequence.imageFolderPath}
          />
          <ExperienceOverlay scrollYProgress={scrollYProgress} phases={content.phases} />
        </div>
      </section>

      <section id="story" className="post-content">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <h2 className="font-heading text-5xl md:text-7xl tracking-wider mb-6">
              The Story
            </h2>
            <p className="text-text-secondary text-lg md:text-xl max-w-2xl mx-auto">
              {content.description}
            </p>
          </motion.div>

          <div id="features" className="feature-grid">
            {content.features.map((feature, index) => (
              <motion.div
                key={feature.title}
                className="feature-card"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <h3 className="font-heading text-2xl tracking-wider mb-3">{feature.title}</h3>
                <p className="text-text-secondary text-sm">{feature.description}</p>
              </motion.div>
            ))}
          </div>

          <footer id="contact" className="mt-24 pt-12 border-t border-neutral-light">
            <div className="text-center">
              <h3 className="font-heading text-4xl tracking-wider mb-4">
                {content.footer.title}
              </h3>
              <p className="text-text-secondary mb-8">{content.footer.description}</p>
              <p className="text-text-secondary/50 text-xs tracking-widest">
                {content.footer.copyright}
              </p>
            </div>
          </footer>
        </div>
      </section>
    </main>
  )
}
