'use client'

import { useEffect, useRef, useState } from 'react'

interface ScrollCanvasProps {
  scrollYProgress: number
  totalFrames: number
  imageFolderPath: string
}

export default function ScrollCanvas({
  scrollYProgress,
  totalFrames,
  imageFolderPath,
}: ScrollCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const imagesRef = useRef<HTMLImageElement[]>([])
  const [isLoaded, setIsLoaded] = useState(false)
  const [aspectRatio, setAspectRatio] = useState(16 / 9)

  useEffect(() => {
    const loadImages = async () => {
      const loadedImages: HTMLImageElement[] = []

      for (let i = 1; i <= totalFrames; i++) {
        const img = new Image()
        const src = `${imageFolderPath}/${i}.jpg`
        img.src = src

        await new Promise<void>((resolve) => {
          img.onload = () => {
            if (i === 1) {
              setAspectRatio(img.width / img.height)
            }
            resolve()
          }
          img.onerror = () => {
            const fallbackCanvas = document.createElement('canvas')
            fallbackCanvas.width = 1920
            fallbackCanvas.height = 1080
            const ctx = fallbackCanvas.getContext('2d')
            if (ctx) {
              const gradient = ctx.createLinearGradient(0, 0, fallbackCanvas.width, fallbackCanvas.height)
              const progress = (i - 1) / (totalFrames - 1)
              gradient.addColorStop(0, `hsl(${220 + progress * 60}, 30%, ${5 + progress * 10}%)`)
              gradient.addColorStop(1, `hsl(${280 + progress * 40}, 40%, ${3 + progress * 8}%)`)
              ctx.fillStyle = gradient
              ctx.fillRect(0, 0, fallbackCanvas.width, fallbackCanvas.height)

              ctx.fillStyle = 'rgba(255, 255, 255, 0.03)'
              ctx.font = 'bold 120px sans-serif'
              ctx.textAlign = 'center'
              ctx.textBaseline = 'middle'
              ctx.fillText(`${i}`, fallbackCanvas.width / 2, fallbackCanvas.height / 2)
            }
            const fallbackImg = new Image()
            fallbackImg.src = fallbackCanvas.toDataURL()
            fallbackImg.onload = () => {
              if (i === 1) {
                setAspectRatio(fallbackImg.width / fallbackImg.height)
              }
              resolve()
            }
          }
        })

        loadedImages.push(img)
      }

      imagesRef.current = loadedImages
      setIsLoaded(true)
    }

    loadImages()
  }, [totalFrames, imageFolderPath])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || !isLoaded || imagesRef.current.length === 0) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const dpr = window.devicePixelRatio || 1
    const displayWidth = canvas.clientWidth
    const displayHeight = canvas.clientHeight

    canvas.width = displayWidth * dpr
    canvas.height = displayHeight * dpr
    ctx.scale(dpr, dpr)

    const frameIndex = Math.min(
      Math.floor(scrollYProgress * totalFrames),
      totalFrames - 1
    )
    const currentImage = imagesRef.current[frameIndex]

    if (currentImage && currentImage.complete) {
      const imgRatio = currentImage.width / currentImage.height
      const canvasRatio = displayWidth / displayHeight

      let drawWidth: number
      let drawHeight: number
      let offsetX: number
      let offsetY: number

      if (imgRatio > canvasRatio) {
        drawHeight = displayHeight
        drawWidth = displayHeight * imgRatio
        offsetX = (displayWidth - drawWidth) / 2
        offsetY = 0
      } else {
        drawWidth = displayWidth
        drawHeight = displayWidth / imgRatio
        offsetX = 0
        offsetY = (displayHeight - drawHeight) / 2
      }

      ctx.fillStyle = '#0a0a0a'
      ctx.fillRect(0, 0, displayWidth, displayHeight)
      ctx.drawImage(currentImage, offsetX, offsetY, drawWidth, drawHeight)
    }
  }, [scrollYProgress, isLoaded, totalFrames])

  return (
    <div className="canvas-wrapper">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ aspectRatio }}
        aria-hidden="true"
      />
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-background">
          <div className="w-8 h-8 border-2 border-accent border-t-transparent rounded-full animate-spin" />
        </div>
      )}
    </div>
  )
}
