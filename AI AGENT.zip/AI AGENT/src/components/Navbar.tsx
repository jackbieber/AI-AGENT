'use client'

import { motion, useScroll, useSpring } from 'framer-motion'
import { useState, useEffect } from 'react'

interface NavbarProps {
  logoText?: string
  ctaText?: string
  ctaHref?: string
}

export default function Navbar({
  logoText = 'TRANSFORM',
  ctaText = 'Get Started',
  ctaHref = '#',
}: NavbarProps) {
  const { scrollYProgress } = useScroll()
  const [isScrolled, setIsScrolled] = useState(false)

  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001,
  })

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled ? 'bg-background/80 backdrop-blur-md border-b border-neutral-light' : 'bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <motion.a
            href="#"
            className="font-heading text-xl md:text-2xl tracking-[0.3em] text-text-primary hover:text-accent transition-colors"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {logoText}
          </motion.a>

          <div className="flex items-center gap-6">
            <div className="hidden md:flex items-center gap-4">
              {['Story', 'Features', 'Contact'].map((item) => (
                <motion.a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-text-secondary text-sm tracking-widest uppercase hover:text-text-primary transition-colors"
                  whileHover={{ y: -2 }}
                >
                  {item}
                </motion.a>
              ))}
            </div>

            <motion.a
              href={ctaHref}
              className="bg-accent text-text-primary px-5 py-2 text-xs tracking-widest uppercase font-body hover:bg-accent/90 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              {ctaText}
            </motion.a>
          </div>
        </div>
      </div>

      <motion.div
        className="absolute bottom-0 left-0 h-px bg-accent origin-left"
        style={{ scaleX: smoothProgress }}
      />
    </motion.nav>
  )
}
