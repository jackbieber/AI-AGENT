'use client'

import { motion, useTransform } from 'framer-motion'
import { useMemo } from 'react'

interface Phase {
  id: string
  title: string
  subtitle?: string
  description?: string
  position: 'left' | 'right' | 'top' | 'bottom'
  alignment?: 'start' | 'center' | 'end'
}

interface ExperienceOverlayProps {
  scrollYProgress: number
  phases: Phase[]
}

export default function ExperienceOverlay({
  scrollYProgress,
  phases,
}: ExperienceOverlayProps) {
  const introPhase = phases[0]
  const mainPhases = phases.slice(1, phases.length - 1)
  const finalPhase = phases[phases.length - 1]

  const isInIntro = scrollYProgress < 0.3
  const isInMain = scrollYProgress >= 0.3 && scrollYProgress < 0.75
  const isInFinal = scrollYProgress >= 0.75

  const mainPhaseIndex = useMemo(() => {
    if (!isInMain) return 0
    const normalizedProgress = (scrollYProgress - 0.3) / 0.45
    return Math.min(
      Math.floor(normalizedProgress * mainPhases.length),
      mainPhases.length - 1
    )
  }, [scrollYProgress, isInMain, mainPhases.length])

  const currentMainPhase = mainPhases[mainPhaseIndex] || mainPhases[0]

  const opacity = useTransform(scrollYProgress, [0, 0.05, 0.95, 1], [0, 1, 1, 0])
  const y = useTransform(scrollYProgress, [0, 0.3], [30, 0])
  const scale = useTransform(scrollYProgress, [0, 0.3], [0.95, 1])

  return (
    <div className="overlay-wrapper">
      {isInIntro && introPhase && (
        <motion.div
          className={`phase-content phase-content--${introPhase.position}`}
          style={{ opacity, y, scale }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <motion.h1
            className="font-heading text-6xl md:text-8xl tracking-wider text-text-primary mb-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {introPhase.title}
          </motion.h1>
          {introPhase.subtitle && (
            <motion.p
              className="text-text-secondary text-lg md:text-xl font-body"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              {introPhase.subtitle}
            </motion.p>
          )}
          {introPhase.description && (
            <motion.p
              className="text-text-secondary/70 text-sm mt-4 max-w-md"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              {introPhase.description}
            </motion.p>
          )}
          <motion.div
            className="mt-8 flex items-center gap-2 text-text-secondary"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <span className="text-xs tracking-widest uppercase">Scroll to explore</span>
            <motion.span
              className="block w-12 h-px bg-text-secondary"
              animate={{ scaleX: [1, 0.5, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </motion.div>
        </motion.div>
      )}

      {isInMain && currentMainPhase && (
        <motion.div
          className={`phase-content phase-content--${currentMainPhase.position}`}
          key={currentMainPhase.id}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <motion.h2
            className="font-heading text-4xl md:text-6xl tracking-wider text-text-primary mb-2"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            {currentMainPhase.title}
          </motion.h2>
          {currentMainPhase.subtitle && (
            <motion.p
              className="text-accent text-sm tracking-widest uppercase font-body mb-3"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              {currentMainPhase.subtitle}
            </motion.p>
          )}
          {currentMainPhase.description && (
            <motion.p
              className="text-text-secondary text-sm md:text-base max-w-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              {currentMainPhase.description}
            </motion.p>
          )}
        </motion.div>
      )}

      {isInFinal && finalPhase && (
        <motion.div
          className={`phase-content phase-content--${finalPhase.position}`}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h2
            className="font-heading text-5xl md:text-7xl tracking-wider text-text-primary mb-4"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            {finalPhase.title}
          </motion.h2>
          {finalPhase.description && (
            <motion.p
              className="text-text-secondary text-base md:text-lg max-w-md mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              {finalPhase.description}
            </motion.p>
          )}
          <motion.button
            className="pointer-events-auto bg-accent text-text-primary px-8 py-3 text-sm tracking-widest uppercase font-body hover:bg-accent/90 transition-colors"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.98 }}
          >
            {finalPhase.subtitle || 'Get Started'}
          </motion.button>
        </motion.div>
      )}
    </div>
  )
}
