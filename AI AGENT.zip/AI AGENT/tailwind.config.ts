import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        background: '#0a0a0a',
        accent: '#ff4d00',
        neutral: '#1a1a1a',
        'neutral-light': '#2a2a2a',
        'text-primary': '#ffffff',
        'text-secondary': '#888888',
      },
      fontFamily: {
        heading: ['var(--font-bebas)', 'sans-serif'],
        body: ['var(--font-inter)', 'sans-serif'],
      },
      height: {
        'scroll-500': '500vh',
        'scroll-600': '600vh',
      },
    },
  },
  plugins: [],
}
export default config
